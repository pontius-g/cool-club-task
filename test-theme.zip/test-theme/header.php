<!DOCTYPE html>
<html dir="ltr" lang="en-US">

<head>

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>

<header>

	<div>
		BLOG HEADER
	</div>

</header>
