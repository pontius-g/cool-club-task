<?php
add_action( 'wp', 'ps_404rw', 1);
?>
