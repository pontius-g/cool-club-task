<footer>

	<div>
		BLOG FOOTER
	</div>

</footer>

<?php wp_footer(); ?>

</body>
</html>
