<?php get_header(); ?>

<main>
<?php get_template_part( 'template-parts/post', 'content' ); ?>
</main>

<?php get_footer(); ?>
